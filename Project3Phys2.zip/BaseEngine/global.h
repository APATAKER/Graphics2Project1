#pragma once



void PhysicsInit();
void PhysicsEnd();
void PhysicsUpdate(float dt);
	
