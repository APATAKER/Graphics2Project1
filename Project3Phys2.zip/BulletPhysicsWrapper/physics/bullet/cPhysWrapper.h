#pragma once

// one file to hold all the headers
#include "cPhysFactory.h"
#include "cPhysWorld.h"
#include "cBallComponent.h"
#include "cPlaneComponent.h"