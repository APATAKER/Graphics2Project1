#pragma once

enum class eShapeTypes
{
	SPHERE,
	PLANE,
	MESH
};